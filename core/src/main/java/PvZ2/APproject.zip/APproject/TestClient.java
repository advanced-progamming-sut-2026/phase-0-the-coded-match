package PvZ2.APproject;

import PvZ2.APproject.client.MessageType;
import PvZ2.APproject.client.NetworkClient;
import PvZ2.APproject.client.Request;
import PvZ2.APproject.client.Response;

import java.util.Map;
import java.util.Scanner;

public class TestClient {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {

        NetworkClient client = new NetworkClient("127.0.0.1", 5000);

        client.setPushListener(response -> {
            System.out.println();
            System.out.println("========== PUSH FROM SERVER ==========");
            printResponse(response);
            System.out.println("======================================");
            System.out.print("> ");
        });

        client.connect();

        System.out.println("Connected to server.");
        System.out.println("Type 'help' to see available commands.");

        while (true) {

            System.out.print("> ");
            String line = scanner.nextLine().trim();

            if (line.equalsIgnoreCase("exit")) {
                client.disconnect();
                System.out.println("Disconnected.");
                break;
            }

            if (line.equalsIgnoreCase("help")) {
                printHelp();
                continue;
            }

            try {
                handleCommand(client, line);
            } catch (Exception e) {
                System.out.println("ERROR: " + e.getMessage());
            }
        }
    }

    private static void handleCommand(NetworkClient client, String line)
        throws Exception {

        String[] parts = line.split(" ", -1);

        if (parts.length == 0) return;

        String command = parts[0].toLowerCase();

        switch (command) {

            case "register" -> {
                require(parts, 6);

                Request r = new Request(MessageType.REGISTER);

                r.put("username", parts[1]);
                r.put("password", parts[2]);
                r.put("passwordConfirm", parts[2]);
                r.put("nickname", parts[3]);
                r.put("email", parts[4]);
                r.put("gender", parts[5]);

                send(client, r);
            }

            case "login" -> {
                require(parts, 3);

                Request r = new Request(MessageType.LOGIN);

                r.put("username", parts[1]);
                r.put("password", parts[2]);

                send(client, r);
            }

            case "logout" -> {
                send(client, new Request(MessageType.LOGOUT));
            }

            case "profile" -> {
                send(client, new Request(MessageType.GET_PROFILE));
            }

            case "update" -> {
                require(parts, 3);

                Request r = new Request(MessageType.UPDATE_PROFILE);

                r.put("field", parts[1]);
                r.put("value", parts[2]);

                if (parts[1].equalsIgnoreCase("password")) {
                    require(parts, 4);
                    r.put("oldPassword", parts[3]);
                }

                send(client, r);
            }

            case "security" -> {
                require(parts, 3);

                Request r = new Request(MessageType.SET_SECURITY_QUESTION);

                r.put("question", parts[1]);
                r.put("answer", parts[2]);

                send(client, r);
            }

            case "forgot" -> {
                require(parts, 3);

                Request r = new Request(MessageType.FORGOT_PASSWORD);

                r.put("username", parts[1]);
                r.put("email", parts[2]);

                send(client, r);
            }

            case "verify" -> {
                require(parts, 3);

                Request r = new Request(MessageType.VERIFY_SECURITY_ANSWER);

                r.put("username", parts[1]);
                r.put("answer", parts[2]);

                send(client, r);
            }

            case "reset" -> {
                require(parts, 3);

                Request r = new Request(MessageType.RESET_PASSWORD);

                r.put("resetToken", parts[1]);
                r.put("password", parts[2]);

                send(client, r);
            }

            case "random" -> {
                require(parts, 2);

                Request r = new Request(MessageType.FIND_RANDOM_MATCH);
                r.put("stage", parts[1]);

                send(client, r);
            }

            case "findplayer" -> {
                require(parts, 3);

                Request r = new Request(MessageType.FIND_PLAYER);

                r.put("username", parts[1]);
                r.put("stage", parts[2]);

                send(client, r);
            }

            case "accept" -> {
                require(parts, 2);

                Request r = new Request(MessageType.ACCEPT_MATCH);
                r.put("invitationId", parts[1]);

                send(client, r);
            }

            case "reject" -> {
                require(parts, 2);

                Request r = new Request(MessageType.REJECT_MATCH);
                r.put("invitationId", parts[1]);

                send(client, r);
            }

            case "action" -> {
                require(parts, 6);

                Request r = new Request(MessageType.GAME_ACTION);

                r.put("action", parts[1]);
                r.put("role", parts[2]);
                r.put("entity", parts[3]);
                r.put("entityType", parts[4]);
                r.put("x", parts[5]);
                r.put("y", parts.length >= 7 ? parts[6] : "1");

                send(client, r);
            }

            case "state" -> {
                send(client, new Request(MessageType.GAME_STATE));
            }

            case "over" -> {
                require(parts, 3);

                Request r = new Request(MessageType.GAME_OVER);

                r.put("winner", parts[1]);
                r.put("reason", parts[2]);

                send(client, r);
            }

            case "reaction" -> {
                require(parts, 3);

                Request r = new Request(MessageType.SEND_REACTION);

                r.put("kind", parts[1]);
                r.put("value", parts[2]);

                send(client, r);
            }

            case "leaderboard" -> {
                require(parts, 3);

                Request r = new Request(MessageType.GET_LEADERBOARD);

                r.put("sort", parts[1]);
                r.put("order", parts[2]);

                send(client, r);
            }

            case "score" -> {
                require(parts, 2);

                Request r = new Request(MessageType.SUBMIT_SCORE);

                r.put("score", parts[1]);

                send(client, r);
            }

            default ->
                System.out.println("Unknown command. Type 'help'.");
        }
    }

    private static void send(NetworkClient client, Request request)
        throws Exception {

        System.out.println();
        System.out.println("---------- REQUEST ----------");
        System.out.println("Type: " + request.getType());
        System.out.println("ID:   " + request.getRequestId());
        System.out.println("Data: " + request.getData());

        Response response = client.sendAndWait(request);

        System.out.println("---------- RESPONSE ---------");
        printResponse(response);
        System.out.println("-----------------------------");
    }

    private static void printResponse(Response response) {

        System.out.println("Type:    " + response.getType());
        System.out.println("Success: " + response.isSuccess());
        System.out.println("Message: " + response.getMessage());
        System.out.println("Data:    " + response.getData());
    }

    private static void require(String[] parts, int minimum)
        throws IllegalArgumentException {

        if (parts.length < minimum) {
            throw new IllegalArgumentException(
                "Not enough arguments. Type 'help'."
            );
        }
    }

    private static void printHelp() {

        System.out.println("""

                ================= TEST COMMANDS =================

                ACCOUNT
                register USER PASSWORD NICKNAME EMAIL GENDER
                login USER PASSWORD
                logout
                profile

                PROFILE
                update nickname NEWNAME
                update email NEWEMAIL
                update password NEWPASSWORD OLDPASSWORD

                SECURITY
                security QUESTION ANSWER
                forgot USER EMAIL
                verify USER ANSWER
                reset RESET_TOKEN NEWPASSWORD

                MATCHMAKING
                random STAGE
                findplayer USER STAGE
                accept INVITATION_ID
                reject INVITATION_ID

                GAME
                action ACTION ROLE ENTITY_ID ENTITY_TYPE X Y
                state
                over WINNER REASON

                REACTIONS
                reaction TEXT "Good luck!"
                reaction EMOJI 😀
                reaction STICKER sticker1

                LEADERBOARD
                leaderboard score descending
                leaderboard score ascending
                leaderboard minigames descending
                leaderboard games descending

                SCORE
                score NUMBER

                EXIT
                exit

                =================================================
                """);
    }
}

