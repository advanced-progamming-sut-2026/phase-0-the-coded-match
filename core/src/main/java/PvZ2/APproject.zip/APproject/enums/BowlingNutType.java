package PvZ2.APproject.enums;

public enum BowlingNutType {
    REGULAR_BOWLING_WALLNUT,
    EXPLODE_O_NUT,
    GIANT_WALLNUT
}
