package PvZ2.APproject.views.actors;

import PvZ2.APproject.controllers.PlantSelectionController;
import PvZ2.APproject.models.plants.PlantData;
import com.badlogic.gdx.scenes.scene2d.Group;

public class PlantBox extends Group {
     private final PlantData plantDatal;
     private final PlantSelectionController selectionController;

    public PlantBox(PlantData plantDatal, PlantSelectionController selectionController) {
        this.plantDatal = plantDatal;
        this.selectionController = selectionController;
    }

    
}
